module.exports = {
  db: {},
  secret: process.env.SHSH_SECRET || 'shshcl4v3' // no usar palabra > default
}
