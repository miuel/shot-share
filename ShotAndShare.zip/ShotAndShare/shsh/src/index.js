require("babel-polyfill");
var page = require('page');

require('./homepage');
require('./signup');
require('./signin');
//requiero la pagina del usuario:
require('./user-page');
require('./footer');



page();